"use client";
import React from "react";

function MainComponent() {
  const [activeTab, setActiveTab] = React.useState("dashboard");
  const [scanData, setScanData] = React.useState({
    epc: "",
    location: "",
    zone_id: "",
    outlet_id: "",
  });
  const [dispatchData, setDispatchData] = React.useState({
    batch: "",
    outlet_id: "",
    quantity: "",
  });
  const [traceEpc, setTraceEpc] = React.useState("");
  const [inventory, setInventory] = React.useState([]);
  const [batchSummary, setBatchSummary] = React.useState([]);
  const [warehouseData, setWarehouseData] = React.useState({
    zones: [],
    outlets: [],
  });
  const [traceResults, setTraceResults] = React.useState(null);
  const [loading, setLoading] = React.useState(false);
  const [message, setMessage] = React.useState("");
  const [bulkMode, setBulkMode] = React.useState(false);
  const [productData, setProductData] = React.useState({
    epc: "",
    name: "",
    batch: "",
    expiry: "",
  });
  const [bulkProducts, setBulkProducts] = React.useState("");
  const [dashboardStats, setDashboardStats] = React.useState({
    totalProducts: 0,
    activeZones: 0,
    recentScans: 0,
    lowStock: 0,
    expiringProducts: 0,
    recentEvents: [],
  });
  const [realTimeMode, setRealTimeMode] = React.useState(false);
  const [searchTerm, setSearchTerm] = React.useState("");
  const [filterZone, setFilterZone] = React.useState("");
  const [filterStatus, setFilterStatus] = React.useState("");

  // Real-time updates simulation
  React.useEffect(() => {
    if (realTimeMode) {
      const interval = setInterval(() => {
        loadDashboardStats();
        if (activeTab === "inventory") {
          loadInventory();
        }
      }, 5000); // Update every 5 seconds
      return () => clearInterval(interval);
    }
  }, [realTimeMode, activeTab]);

  const loadDashboardStats = async () => {
    try {
      const response = await fetch("/api/dashboard-stats", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });

      if (!response.ok) {
        throw new Error(`Dashboard stats load failed: ${response.status}`);
      }

      const result = await response.json();
      setDashboardStats(result);
    } catch (error) {
      console.error(error);
      setMessage("Failed to load dashboard statistics");
    }
  };

  const loadWarehouseData = async () => {
    try {
      const response = await fetch("/api/warehouse", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });

      if (!response.ok) {
        throw new Error(`Warehouse data load failed: ${response.status}`);
      }

      const result = await response.json();
      setWarehouseData(result);
    } catch (error) {
      console.error(error);
      setMessage("Failed to load warehouse data");
    }
  };

  React.useEffect(() => {
    loadWarehouseData();
    loadDashboardStats();
  }, []);

  const handleScan = async () => {
    if (!scanData.epc || !scanData.location) {
      setMessage("Please enter both EPC code and location");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("/api/scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          epc: scanData.epc,
          location: scanData.location,
          zone_id: scanData.zone_id || null,
          outlet_id: scanData.outlet_id || null,
        }),
      });

      if (!response.ok) {
        throw new Error(`Scan failed: ${response.status}`);
      }

      const result = await response.json();
      if (result.error) {
        setMessage(`Error: ${result.error}`);
      } else {
        let locationInfo = result.event.location;
        if (result.zone) locationInfo += ` (${result.zone.zone_name})`;
        if (result.outlet) locationInfo += ` → ${result.outlet.name}`;

        setMessage(
          `Scan recorded for ${result.product.name} at ${locationInfo}`
        );
        setScanData({ epc: "", location: "", zone_id: "", outlet_id: "" });
      }
    } catch (error) {
      console.error(error);
      setMessage("Failed to record scan");
    }
    setLoading(false);
  };

  const handleAddProduct = async () => {
    if (
      !productData.epc ||
      !productData.name ||
      !productData.batch ||
      !productData.expiry
    ) {
      setMessage("Please fill in all product fields");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("/api/add-product", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          epc: productData.epc,
          name: productData.name,
          batch: productData.batch,
          expiry: productData.expiry,
        }),
      });

      if (!response.ok) {
        throw new Error(`Add product failed: ${response.status}`);
      }

      const result = await response.json();
      if (result.error) {
        setMessage(`Error: ${result.error}`);
      } else {
        setMessage(`Successfully added product: ${productData.name}`);
        setProductData({ epc: "", name: "", batch: "", expiry: "" });
        if (activeTab === "inventory") {
          loadInventory();
        }
      }
    } catch (error) {
      console.error(error);
      setMessage("Failed to add product");
    }
    setLoading(false);
  };

  const handleBulkAddProducts = async () => {
    if (!bulkProducts.trim()) {
      setMessage("Please enter product data for bulk add");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("/api/bulk-add-products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          products_data: bulkProducts,
        }),
      });

      if (!response.ok) {
        throw new Error(`Bulk add products failed: ${response.status}`);
      }

      const result = await response.json();
      if (result.error) {
        setMessage(`Error: ${result.error}`);
      } else {
        setMessage(
          `Successfully added ${result.products_added} products. ${
            result.errors ? `Errors: ${result.errors}` : ""
          }`
        );
        setBulkProducts("");
        if (activeTab === "inventory") {
          loadInventory();
        }
      }
    } catch (error) {
      console.error(error);
      setMessage("Failed to bulk add products");
    }
    setLoading(false);
  };

  const handleDispatch = async () => {
    if (
      !dispatchData.batch ||
      !dispatchData.outlet_id ||
      !dispatchData.quantity
    ) {
      setMessage("Please fill in all dispatch fields");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("/api/dispatch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          batch: dispatchData.batch,
          outlet_id: parseInt(dispatchData.outlet_id),
          quantity: parseInt(dispatchData.quantity),
        }),
      });

      if (!response.ok) {
        throw new Error(`Dispatch failed: ${response.status}`);
      }

      const result = await response.json();
      if (result.error) {
        setMessage(`Error: ${result.error}`);
      } else {
        setMessage(
          `Successfully dispatched ${result.products_dispatched} products from batch ${dispatchData.batch} to ${result.outlet.name}`
        );
        setDispatchData({ batch: "", outlet_id: "", quantity: "" });
        if (activeTab === "inventory") {
          loadInventory();
        }
      }
    } catch (error) {
      console.error(error);
      setMessage("Failed to dispatch products");
    }
    setLoading(false);
  };

  const handleTrace = async () => {
    if (!traceEpc) {
      setMessage("Please enter an EPC code to trace");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("/api/trace", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ epc: traceEpc }),
      });

      if (!response.ok) {
        throw new Error(`Trace failed: ${response.status}`);
      }

      const result = await response.json();
      if (result.error) {
        setMessage(`Error: ${result.error}`);
        setTraceResults(null);
      } else {
        setTraceResults(result);
        setMessage("");
      }
    } catch (error) {
      console.error(error);
      setMessage("Failed to trace product");
      setTraceResults(null);
    }
    setLoading(false);
  };

  const loadInventory = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/inventory", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });

      if (!response.ok) {
        throw new Error(`Inventory load failed: ${response.status}`);
      }

      const result = await response.json();
      setInventory(result.inventory || []);
      setBatchSummary(result.batch_summary || []);
      setMessage("");
    } catch (error) {
      console.error(error);
      setMessage("Failed to load inventory");
    }
    setLoading(false);
  };

  React.useEffect(() => {
    if (activeTab === "inventory") {
      loadInventory();
    }
  }, [activeTab]);

  const filteredInventory = inventory.filter((item) => {
    const matchesSearch =
      !searchTerm ||
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.epc.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.batch.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesZone = !filterZone || item.zone_name === filterZone;

    const matchesStatus =
      !filterStatus ||
      (filterStatus === "in_warehouse" && !item.outlet_name) ||
      (filterStatus === "dispatched" && item.outlet_name) ||
      (filterStatus === "expiring" &&
        new Date(item.expiry) <=
          new Date(Date.now() + 7 * 24 * 60 * 60 * 1000));

    return matchesSearch && matchesZone && matchesStatus;
  });

  const formatDate = (dateString) => {
    if (!dateString) return "Never scanned";
    return new Date(dateString).toLocaleString();
  };

  const getLocationDisplay = (item) => {
    let display = item.location || "Unknown";
    if (item.zone_name) {
      display += ` (${item.zone_name})`;
    }
    if (item.outlet_name) {
      display = `${item.outlet_name} - ${item.outlet_location}`;
    }
    return display;
  };

  const getStatusColor = (item) => {
    if (item.outlet_name) return "bg-blue-100 text-blue-800";
    if (item.zone_name) return "bg-green-100 text-green-800";
    return "bg-gray-100 text-gray-800";
  };

  const getExpiryStatus = (expiryDate) => {
    const today = new Date();
    const expiry = new Date(expiryDate);
    const daysUntilExpiry = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));

    if (daysUntilExpiry < 0)
      return {
        status: "expired",
        color: "bg-red-100 text-red-800",
        text: "Expired",
      };
    if (daysUntilExpiry <= 3)
      return {
        status: "critical",
        color: "bg-red-100 text-red-800",
        text: `${daysUntilExpiry}d left`,
      };
    if (daysUntilExpiry <= 7)
      return {
        status: "warning",
        color: "bg-yellow-100 text-yellow-800",
        text: `${daysUntilExpiry}d left`,
      };
    return {
      status: "good",
      color: "bg-green-100 text-green-800",
      text: `${daysUntilExpiry}d left`,
    };
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                PFIL RFID Tracking System
              </h1>
              <p className="text-sm text-gray-600">
                Real-time inventory and asset tracking
              </p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-600">Real-time updates</span>
                <button
                  onClick={() => setRealTimeMode(!realTimeMode)}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    realTimeMode ? "bg-blue-600" : "bg-gray-200"
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      realTimeMode ? "translate-x-6" : "translate-x-1"
                    }`}
                  />
                </button>
              </div>
              {realTimeMode && (
                <div className="flex items-center space-x-1 text-green-600">
                  <div className="w-2 h-2 bg-green-600 rounded-full animate-pulse"></div>
                  <span className="text-sm">Live</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-4">
        {/* Tab Navigation */}
        <div className="flex space-x-1 bg-white p-1 rounded-lg mb-6 overflow-x-auto shadow-sm">
          {[
            { id: "dashboard", label: "Dashboard", icon: "📊" },
            { id: "scan", label: "Live Scan", icon: "📱" },
            { id: "products", label: "Products", icon: "📦" },
            { id: "dispatch", label: "Dispatch", icon: "🚚" },
            { id: "trace", label: "Trace", icon: "🔍" },
            { id: "inventory", label: "Inventory", icon: "📋" },
            { id: "warehouse", label: "Warehouse", icon: "🏭" },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 flex-1 py-3 px-4 rounded-md font-medium transition-colors whitespace-nowrap ${
                activeTab === tab.id
                  ? "bg-blue-600 text-white shadow-sm"
                  : "text-gray-600 hover:text-gray-900 hover:bg-gray-50"
              }`}
            >
              <span>{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Message Display */}
        {message && (
          <div
            className={`p-4 rounded-lg mb-6 ${
              message.includes("Error") || message.includes("Failed")
                ? "bg-red-100 text-red-700 border border-red-200"
                : "bg-green-100 text-green-700 border border-green-200"
            }`}
          >
            <pre className="whitespace-pre-wrap">{message}</pre>
          </div>
        )}

        {/* Dashboard Tab */}
        {activeTab === "dashboard" && (
          <div className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      Total Products
                    </p>
                    <p className="text-2xl font-bold text-gray-900">
                      {dashboardStats.totalProducts}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <span className="text-2xl">📦</span>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      Active Zones
                    </p>
                    <p className="text-2xl font-bold text-gray-900">
                      {dashboardStats.activeZones}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <span className="text-2xl">🏭</span>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      Recent Scans
                    </p>
                    <p className="text-2xl font-bold text-gray-900">
                      {dashboardStats.recentScans}
                    </p>
                    <p className="text-xs text-gray-500">Last 24h</p>
                  </div>
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                    <span className="text-2xl">📱</span>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      Low Stock
                    </p>
                    <p className="text-2xl font-bold text-orange-600">
                      {dashboardStats.lowStock}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                    <span className="text-2xl">⚠️</span>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      Expiring Soon
                    </p>
                    <p className="text-2xl font-bold text-red-600">
                      {dashboardStats.expiringProducts}
                    </p>
                    <p className="text-xs text-gray-500">Next 7 days</p>
                  </div>
                  <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                    <span className="text-2xl">⏰</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>
              <div className="space-y-3">
                {dashboardStats.recentEvents.length === 0 ? (
                  <p className="text-gray-500 italic">No recent activity</p>
                ) : (
                  dashboardStats.recentEvents.map((event, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                    >
                      <div className="flex items-center space-x-3">
                        <div
                          className={`w-3 h-3 rounded-full ${
                            event.type === "scan"
                              ? "bg-blue-500"
                              : event.type === "dispatch"
                              ? "bg-green-500"
                              : "bg-purple-500"
                          }`}
                        ></div>
                        <div>
                          <p className="font-medium">{event.description}</p>
                          <p className="text-sm text-gray-600">
                            {event.location}
                          </p>
                        </div>
                      </div>
                      <span className="text-sm text-gray-500">
                        {formatDate(event.timestamp)}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {/* Live Scan Tab */}
        {activeTab === "scan" && (
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-xl font-semibold mb-4 flex items-center space-x-2">
              <span>📱</span>
              <span>Live RFID Scan</span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  EPC Code *
                </label>
                <input
                  type="text"
                  value={scanData.epc}
                  onChange={(e) =>
                    setScanData({ ...scanData, epc: e.target.value })
                  }
                  placeholder="Scan or enter EPC"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Location *
                </label>
                <input
                  type="text"
                  value={scanData.location}
                  onChange={(e) =>
                    setScanData({ ...scanData, location: e.target.value })
                  }
                  placeholder="Current location"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Zone (Optional)
                </label>
                <select
                  value={scanData.zone_id}
                  onChange={(e) =>
                    setScanData({ ...scanData, zone_id: e.target.value })
                  }
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Select Zone</option>
                  {warehouseData.zones.map((zone) => (
                    <option key={zone.id} value={zone.id}>
                      {zone.zone_name} ({zone.zone_type})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Outlet (Optional)
                </label>
                <select
                  value={scanData.outlet_id}
                  onChange={(e) =>
                    setScanData({ ...scanData, outlet_id: e.target.value })
                  }
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Select Outlet</option>
                  {warehouseData.outlets.map((outlet) => (
                    <option key={outlet.id} value={outlet.id}>
                      {outlet.name} - {outlet.location}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <button
              onClick={handleScan}
              disabled={loading}
              className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed font-medium"
            >
              {loading ? "Recording Scan..." : "Record Scan"}
            </button>
          </div>
        )}

        {/* Enhanced Inventory Tab */}
        {activeTab === "inventory" && (
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-semibold flex items-center space-x-2">
                <span>📋</span>
                <span>Smart Inventory Management</span>
              </h2>
              <button
                onClick={loadInventory}
                disabled={loading}
                className="bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? "Loading..." : "Refresh"}
              </button>
            </div>

            {/* Filters */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Search
                </label>
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search products, EPC, batch..."
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Zone
                </label>
                <select
                  value={filterZone}
                  onChange={(e) => setFilterZone(e.target.value)}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">All Zones</option>
                  {warehouseData.zones.map((zone) => (
                    <option key={zone.id} value={zone.zone_name}>
                      {zone.zone_name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Status
                </label>
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">All Status</option>
                  <option value="in_warehouse">In Warehouse</option>
                  <option value="dispatched">Dispatched</option>
                  <option value="expiring">Expiring Soon</option>
                </select>
              </div>
              <div className="flex items-end">
                <button
                  onClick={() => {
                    setSearchTerm("");
                    setFilterZone("");
                    setFilterStatus("");
                  }}
                  className="w-full bg-gray-600 text-white py-3 px-4 rounded-lg hover:bg-gray-700"
                >
                  Clear Filters
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full table-auto">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="px-4 py-3 text-left font-medium text-gray-700">
                      Product
                    </th>
                    <th className="px-4 py-3 text-left font-medium text-gray-700">
                      EPC
                    </th>
                    <th className="px-4 py-3 text-left font-medium text-gray-700">
                      Batch
                    </th>
                    <th className="px-4 py-3 text-left font-medium text-gray-700">
                      Expiry Status
                    </th>
                    <th className="px-4 py-3 text-left font-medium text-gray-700">
                      Current Location
                    </th>
                    <th className="px-4 py-3 text-left font-medium text-gray-700">
                      Last Seen
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filteredInventory.map((item) => {
                    const expiryStatus = getExpiryStatus(item.expiry);
                    return (
                      <tr
                        key={item.epc}
                        className="border-t border-gray-200 hover:bg-gray-50"
                      >
                        <td className="px-4 py-3 font-medium">{item.name}</td>
                        <td className="px-4 py-3 text-sm text-gray-600 font-mono">
                          {item.epc}
                        </td>
                        <td className="px-4 py-3 text-sm">{item.batch}</td>
                        <td className="px-4 py-3">
                          <span
                            className={`px-2 py-1 rounded-full text-xs font-medium ${expiryStatus.color}`}
                          >
                            {expiryStatus.text}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <span
                            className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(
                              item
                            )}`}
                          >
                            {getLocationDisplay(item)}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-600">
                          {formatDate(item.last_seen)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>

              {filteredInventory.length === 0 && !loading && (
                <div className="text-center py-8 text-gray-500">
                  {searchTerm || filterZone || filterStatus
                    ? "No products match your filters"
                    : "No products found in inventory"}
                </div>
              )}
            </div>

            <div className="mt-4 text-sm text-gray-600">
              Showing {filteredInventory.length} of {inventory.length} products
            </div>
          </div>
        )}

        {/* Products Tab */}
        {activeTab === "products" && (
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">Manage Products</h2>

            {/* Mode Toggle */}
            <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg mb-6 w-fit">
              <button
                onClick={() => setBulkMode(false)}
                className={`py-2 px-4 rounded-md font-medium transition-colors ${
                  !bulkMode
                    ? "bg-white text-blue-600 shadow-sm"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Single Product
              </button>
              <button
                onClick={() => setBulkMode(true)}
                className={`py-2 px-4 rounded-md font-medium transition-colors ${
                  bulkMode
                    ? "bg-white text-blue-600 shadow-sm"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Bulk Add
              </button>
            </div>

            {!bulkMode ? (
              /* Single Product Form */
              <div>
                <h3 className="text-lg font-semibold mb-4">
                  Add Single Product
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      EPC Code *
                    </label>
                    <input
                      type="text"
                      value={productData.epc}
                      onChange={(e) =>
                        setProductData({ ...productData, epc: e.target.value })
                      }
                      placeholder="e.g., EPC123456"
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Product Name *
                    </label>
                    <input
                      type="text"
                      value={productData.name}
                      onChange={(e) =>
                        setProductData({ ...productData, name: e.target.value })
                      }
                      placeholder="e.g., Milk 1L"
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Batch Number *
                    </label>
                    <input
                      type="text"
                      value={productData.batch}
                      onChange={(e) =>
                        setProductData({
                          ...productData,
                          batch: e.target.value,
                        })
                      }
                      placeholder="e.g., B20250801"
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Expiry Date *
                    </label>
                    <input
                      type="date"
                      value={productData.expiry}
                      onChange={(e) =>
                        setProductData({
                          ...productData,
                          expiry: e.target.value,
                        })
                      }
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>
                <button
                  onClick={handleAddProduct}
                  disabled={loading}
                  className="w-full bg-purple-600 text-white py-3 px-4 rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed font-medium"
                >
                  {loading ? "Adding Product..." : "Add Product"}
                </button>
              </div>
            ) : (
              /* Bulk Add Form */
              <div>
                <h3 className="text-lg font-semibold mb-4">
                  Bulk Add Products
                </h3>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Product Data (CSV Format) *
                  </label>
                  <div className="mb-2 text-sm text-gray-600">
                    Format: EPC Code, Product Name, Batch Number, Expiry Date
                    (YYYY-MM-DD)
                    <br />
                    Example: EPC123456, Milk 1L, B20250801, 2025-08-15
                  </div>
                  <textarea
                    value={bulkProducts}
                    onChange={(e) => setBulkProducts(e.target.value)}
                    placeholder={`EPC123456, Milk 1L, B20250801, 2025-08-15
EPC123457, Bread 500g, B20250801, 2025-08-10
EPC123458, Cheese 200g, B20250802, 2025-09-01`}
                    rows={8}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-sm"
                  />
                </div>
                <button
                  onClick={handleBulkAddProducts}
                  disabled={loading}
                  className="w-full bg-purple-600 text-white py-3 px-4 rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed font-medium"
                >
                  {loading ? "Adding Products..." : "Bulk Add Products"}
                </button>
              </div>
            )}

            {/* Instructions */}
            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <h4 className="font-medium text-blue-900 mb-2">Instructions:</h4>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• EPC codes must be unique across all products</li>
                <li>• All fields are required for each product</li>
                <li>• Expiry dates should be in YYYY-MM-DD format</li>
                <li>• For bulk add, use comma-separated values (CSV format)</li>
                <li>• Products will appear in inventory after being added</li>
              </ul>
            </div>
          </div>
        )}

        {/* Dispatch Tab */}
        {activeTab === "dispatch" && (
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">
              Dispatch Products to Outlets
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Batch Number
                </label>
                <input
                  type="text"
                  value={dispatchData.batch}
                  onChange={(e) =>
                    setDispatchData({ ...dispatchData, batch: e.target.value })
                  }
                  placeholder="e.g., B20250801"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Outlet
                </label>
                <select
                  value={dispatchData.outlet_id}
                  onChange={(e) =>
                    setDispatchData({
                      ...dispatchData,
                      outlet_id: e.target.value,
                    })
                  }
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Select Outlet</option>
                  {warehouseData.outlets.map((outlet) => (
                    <option key={outlet.id} value={outlet.id}>
                      {outlet.name} - {outlet.location}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Quantity
                </label>
                <input
                  type="number"
                  value={dispatchData.quantity}
                  onChange={(e) =>
                    setDispatchData({
                      ...dispatchData,
                      quantity: e.target.value,
                    })
                  }
                  placeholder="Number of products"
                  min="1"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
            <button
              onClick={handleDispatch}
              disabled={loading}
              className="w-full bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed font-medium"
            >
              {loading ? "Dispatching..." : "Dispatch Products"}
            </button>

            {/* Batch Summary */}
            {batchSummary.length > 0 && (
              <div className="mt-6">
                <h3 className="text-lg font-semibold mb-3">Batch Summary</h3>
                <div className="overflow-x-auto">
                  <table className="w-full table-auto">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="px-4 py-3 text-left font-medium text-gray-700">
                          Batch
                        </th>
                        <th className="px-4 py-3 text-left font-medium text-gray-700">
                          Total
                        </th>
                        <th className="px-4 py-3 text-left font-medium text-gray-700">
                          Dispatched
                        </th>
                        <th className="px-4 py-3 text-left font-medium text-gray-700">
                          In Storage
                        </th>
                        <th className="px-4 py-3 text-left font-medium text-gray-700">
                          Outlets
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {batchSummary.map((batch) => (
                        <tr
                          key={batch.batch}
                          className="border-t border-gray-200"
                        >
                          <td className="px-4 py-3 font-medium">
                            {batch.batch}
                          </td>
                          <td className="px-4 py-3">{batch.total_products}</td>
                          <td className="px-4 py-3">
                            {batch.dispatched_count}
                          </td>
                          <td className="px-4 py-3">{batch.in_storage}</td>
                          <td className="px-4 py-3 text-sm">
                            {batch.dispatched_to_outlets || "None"}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Trace Tab */}
        {activeTab === "trace" && (
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">
              Trace Product History
            </h2>
            <div className="flex gap-4 mb-6">
              <input
                type="text"
                value={traceEpc}
                onChange={(e) => setTraceEpc(e.target.value)}
                placeholder="Enter EPC code to trace"
                className="flex-1 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <button
                onClick={handleTrace}
                disabled={loading}
                className="bg-green-600 text-white py-3 px-6 rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed font-medium"
              >
                {loading ? "Tracing..." : "Trace"}
              </button>
            </div>

            {traceResults && (
              <div>
                <div className="bg-gray-50 p-4 rounded-lg mb-4">
                  <h3 className="font-semibold text-lg">
                    {traceResults.product.name}
                  </h3>
                  <p className="text-gray-600">
                    Batch: {traceResults.product.batch}
                  </p>
                  <p className="text-gray-600">
                    Expiry: {traceResults.product.expiry}
                  </p>
                  <p className="text-gray-600">
                    Total Events: {traceResults.totalEvents}
                  </p>
                </div>

                <div className="space-y-3">
                  <h4 className="font-medium">Scan History:</h4>
                  {traceResults.events.length === 0 ? (
                    <p className="text-gray-500 italic">
                      No scan events recorded
                    </p>
                  ) : (
                    traceResults.events.map((event, index) => (
                      <div
                        key={event.id}
                        className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                      >
                        <div>
                          <span className="font-medium">{event.location}</span>
                          <span className="text-gray-500 ml-2">
                            #{index + 1}
                          </span>
                        </div>
                        <span className="text-sm text-gray-600">
                          {formatDate(event.timestamp)}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Warehouse Map Tab */}
        {activeTab === "warehouse" && (
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">Warehouse Topology</h2>

            {/* Warehouse Zones */}
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-3">Warehouse Zones</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {warehouseData.zones.map((zone) => (
                  <div
                    key={zone.id}
                    className="border border-gray-200 rounded-lg p-4"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-medium">{zone.zone_name}</h4>
                      <span
                        className={`px-2 py-1 rounded-full text-xs font-medium ${
                          zone.zone_type === "storage"
                            ? "bg-blue-100 text-blue-800"
                            : zone.zone_type === "dispatch"
                            ? "bg-green-100 text-green-800"
                            : zone.zone_type === "receiving"
                            ? "bg-yellow-100 text-yellow-800"
                            : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        {zone.zone_type}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mb-1">
                      Location: {zone.coordinates}
                    </p>
                    <p className="text-sm text-gray-600 mb-1">
                      Capacity: {zone.capacity}
                    </p>
                    <p className="text-sm text-gray-600">
                      Current: {zone.current_products} products
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Outlets */}
            <div>
              <h3 className="text-lg font-semibold mb-3">Dispatch Outlets</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {warehouseData.outlets.map((outlet) => (
                  <div
                    key={outlet.id}
                    className="border border-gray-200 rounded-lg p-4"
                  >
                    <h4 className="font-medium mb-2">{outlet.name}</h4>
                    <p className="text-sm text-gray-600 mb-1">
                      Location: {outlet.location}
                    </p>
                    <p className="text-sm text-gray-600 mb-1">
                      Total Dispatches: {outlet.total_dispatches}
                    </p>
                    <p className="text-sm text-gray-600">
                      Products Dispatched: {outlet.total_quantity_dispatched}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="bg-white border-t mt-8">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="text-center">
            <p className="text-gray-600 mb-2">
              © 2025 PFIL. All rights reserved.
            </p>
            <p className="text-gray-500 text-sm">
              Developed by{" "}
              <span className="text-blue-600 font-medium">
                Denserlink Solutions
              </span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;