async function handler({ epc, name, batch, expiry }) {
  if (!epc || !name || !batch || !expiry) {
    return { error: "EPC code, name, batch, and expiry date are required" };
  }

  const existingProduct =
    await sql`SELECT epc FROM products WHERE epc = ${epc}`;

  if (existingProduct.length > 0) {
    return { error: "EPC code already exists" };
  }

  const product = await sql`
    INSERT INTO products (epc, name, batch, expiry)
    VALUES (${epc}, ${name}, ${batch}, ${expiry})
    RETURNING *
  `;

  return {
    success: true,
    product: product[0],
    message: `Product ${name} added successfully with EPC ${epc}`,
  };
}
export async function POST(request) {
  return handler(await request.json());
}