async function handler({ epc }) {
  if (!epc) {
    return { error: "EPC code is required" };
  }

  const product = await sql`SELECT * FROM products WHERE epc = ${epc}`;

  if (product.length === 0) {
    return { error: "Product not found" };
  }

  const events = await sql`
    SELECT * FROM rfid_events 
    WHERE epc = ${epc} 
    ORDER BY timestamp ASC
  `;

  return {
    product: product[0],
    events: events,
    totalEvents: events.length,
  };
}
export async function POST(request) {
  return handler(await request.json());
}