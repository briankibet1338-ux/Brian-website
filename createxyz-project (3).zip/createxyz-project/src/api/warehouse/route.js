async function handler() {
  const zones = await sql`
    SELECT 
      wz.id,
      wz.zone_name,
      wz.zone_type,
      wz.coordinates,
      wz.capacity,
      COUNT(DISTINCT re.epc) as current_products
    FROM warehouse_zones wz
    LEFT JOIN rfid_events re ON wz.id = re.zone_id
    GROUP BY wz.id, wz.zone_name, wz.zone_type, wz.coordinates, wz.capacity
    ORDER BY wz.zone_name
  `;

  const outlets = await sql`
    SELECT 
      o.id,
      o.name,
      o.location,
      o.contact_info,
      COUNT(DISTINCT dr.id) as total_dispatches,
      COALESCE(SUM(dr.quantity), 0) as total_quantity_dispatched
    FROM outlets o
    LEFT JOIN dispatch_records dr ON o.id = dr.outlet_id
    GROUP BY o.id, o.name, o.location, o.contact_info
    ORDER BY o.name
  `;

  const dispatchStats = await sql`
    SELECT 
      COUNT(*) as total_dispatches,
      SUM(quantity) as total_products_dispatched,
      COUNT(DISTINCT outlet_id) as active_outlets,
      COUNT(DISTINCT batch) as batches_dispatched
    FROM dispatch_records
  `;

  const zoneStats = await sql`
    SELECT 
      COUNT(*) as total_zones,
      COUNT(CASE WHEN zone_type = 'storage' THEN 1 END) as storage_zones,
      COUNT(CASE WHEN zone_type = 'processing' THEN 1 END) as processing_zones,
      COUNT(CASE WHEN zone_type = 'shipping' THEN 1 END) as shipping_zones,
      SUM(capacity) as total_capacity
    FROM warehouse_zones
  `;

  return {
    zones: zones,
    outlets: outlets,
    dispatch_statistics: dispatchStats[0],
    zone_statistics: zoneStats[0],
    total_zones: zones.length,
    total_outlets: outlets.length,
  };
}
export async function POST(request) {
  return handler(await request.json());
}