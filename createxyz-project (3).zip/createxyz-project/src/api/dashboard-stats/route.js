async function handler() {
  const [
    totalProducts,
    activeZones,
    recentScans,
    lowStock,
    expiringProducts,
    recentEvents,
  ] = await sql.transaction([
    sql`SELECT COUNT(*) as count FROM products`,

    sql`SELECT COUNT(DISTINCT wz.id) as count 
        FROM warehouse_zones wz 
        INNER JOIN rfid_events re ON wz.id = re.zone_id`,

    sql`SELECT COUNT(*) as count 
        FROM rfid_events 
        WHERE timestamp >= NOW() - INTERVAL '24 hours'`,

    sql`SELECT COUNT(DISTINCT p.batch) as count
        FROM products p
        LEFT JOIN rfid_events re ON p.epc = re.epc
        WHERE re.outlet_id IS NULL
        GROUP BY p.batch
        HAVING COUNT(*) < 10`,

    sql`SELECT COUNT(*) as count 
        FROM products 
        WHERE expiry <= CURRENT_DATE + INTERVAL '7 days'
        AND expiry >= CURRENT_DATE`,

    sql`SELECT 
          re.epc,
          p.name as product_name,
          re.location,
          re.timestamp,
          CASE 
            WHEN re.outlet_id IS NOT NULL THEN 'dispatch'
            WHEN re.zone_id IS NOT NULL THEN 'scan'
            ELSE 'scan'
          END as type,
          CASE 
            WHEN re.outlet_id IS NOT NULL THEN CONCAT('Dispatched to ', o.name)
            WHEN re.zone_id IS NOT NULL THEN CONCAT('Scanned in ', wz.zone_name)
            ELSE CONCAT('Scanned at ', re.location)
          END as description
        FROM rfid_events re
        LEFT JOIN products p ON re.epc = p.epc
        LEFT JOIN warehouse_zones wz ON re.zone_id = wz.id
        LEFT JOIN outlets o ON re.outlet_id = o.id
        ORDER BY re.timestamp DESC
        LIMIT 10`,
  ]);

  return {
    totalProducts: parseInt(totalProducts[0].count),
    activeZones: parseInt(activeZones[0].count),
    recentScans: parseInt(recentScans[0].count),
    lowStock: lowStock.length,
    expiringProducts: parseInt(expiringProducts[0].count),
    recentEvents: recentEvents.map((event) => ({
      epc: event.epc,
      product_name: event.product_name,
      location: event.location,
      timestamp: event.timestamp,
      type: event.type,
      description: event.description,
    })),
  };
}
export async function POST(request) {
  return handler(await request.json());
}