async function handler({ products }) {
  if (!products || !Array.isArray(products) || products.length === 0) {
    return { error: "Products array is required and must not be empty" };
  }

  const errors = [];
  const validProducts = [];
  const duplicateEpcs = new Set();

  for (let i = 0; i < products.length; i++) {
    const product = products[i];
    const { epc, name, batch, expiry } = product;

    if (!epc || !name || !batch || !expiry) {
      errors.push({
        index: i,
        epc: epc || "missing",
        error: "EPC code, name, batch, and expiry date are required",
      });
      continue;
    }

    if (duplicateEpcs.has(epc)) {
      errors.push({
        index: i,
        epc: epc,
        error: "Duplicate EPC code in request",
      });
      continue;
    }

    duplicateEpcs.add(epc);
    validProducts.push({ epc, name, batch, expiry, index: i });
  }

  if (validProducts.length === 0) {
    return {
      error: "No valid products to add",
      errors: errors,
      total_attempted: products.length,
      valid_count: 0,
      error_count: errors.length,
    };
  }

  const epcs = validProducts.map((p) => p.epc);
  const existingProducts = await sql(
    "SELECT epc FROM products WHERE epc = ANY($1)",
    [epcs]
  );
  const existingEpcs = new Set(existingProducts.map((p) => p.epc));

  const productsToInsert = [];
  for (const product of validProducts) {
    if (existingEpcs.has(product.epc)) {
      errors.push({
        index: product.index,
        epc: product.epc,
        error: "EPC code already exists in database",
      });
    } else {
      productsToInsert.push(product);
    }
  }

  if (productsToInsert.length === 0) {
    return {
      error: "No new products to add - all EPCs already exist",
      errors: errors,
      total_attempted: products.length,
      valid_count: 0,
      error_count: errors.length,
      duplicate_count: errors.filter((e) => e.error.includes("already exists"))
        .length,
    };
  }

  let insertedProducts = [];
  if (productsToInsert.length > 0) {
    const values = [];
    const placeholders = [];

    for (let i = 0; i < productsToInsert.length; i++) {
      const product = productsToInsert[i];
      const baseIndex = i * 4;
      placeholders.push(
        `($${baseIndex + 1}, $${baseIndex + 2}, $${baseIndex + 3}, $${
          baseIndex + 4
        })`
      );
      values.push(product.epc, product.name, product.batch, product.expiry);
    }

    const query = `
      INSERT INTO products (epc, name, batch, expiry)
      VALUES ${placeholders.join(", ")}
      RETURNING *
    `;

    insertedProducts = await sql(query, values);
  }

  return {
    success: true,
    total_attempted: products.length,
    successfully_added: insertedProducts.length,
    error_count: errors.length,
    inserted_products: insertedProducts,
    errors: errors.length > 0 ? errors : undefined,
    message: `Successfully added ${insertedProducts.length} products. ${
      errors.length > 0 ? `${errors.length} products had errors.` : ""
    }`,
  };
}
export async function POST(request) {
  return handler(await request.json());
}