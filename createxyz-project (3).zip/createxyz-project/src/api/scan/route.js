async function handler({ epc, location, zone_id, outlet_id }) {
  if (!epc || !location) {
    return { error: "EPC code and location are required" };
  }

  const product = await sql`SELECT * FROM products WHERE epc = ${epc}`;

  if (product.length === 0) {
    return { error: "Product not found" };
  }

  // Validate zone if provided
  let zone = null;
  if (zone_id) {
    const zoneResult =
      await sql`SELECT * FROM warehouse_zones WHERE id = ${zone_id}`;
    if (zoneResult.length === 0) {
      return { error: "Zone not found" };
    }
    zone = zoneResult[0];
  }

  // Validate outlet if provided
  let outlet = null;
  if (outlet_id) {
    const outletResult =
      await sql`SELECT * FROM outlets WHERE id = ${outlet_id}`;
    if (outletResult.length === 0) {
      return { error: "Outlet not found" };
    }
    outlet = outletResult[0];
  }

  const event = await sql`
    INSERT INTO rfid_events (epc, location, zone_id, outlet_id) 
    VALUES (${epc}, ${location}, ${zone_id || null}, ${outlet_id || null}) 
    RETURNING *
  `;

  return {
    event: event[0],
    product: product[0],
    zone: zone,
    outlet: outlet,
  };
}
export async function POST(request) {
  return handler(await request.json());
}