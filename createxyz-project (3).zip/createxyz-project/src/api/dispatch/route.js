async function handler({ batch, outlet_id, quantity }) {
  if (!batch || !outlet_id || !quantity) {
    return { error: "Batch, outlet ID, and quantity are required" };
  }

  if (quantity <= 0) {
    return { error: "Quantity must be greater than 0" };
  }

  const outlet = await sql`SELECT * FROM outlets WHERE id = ${outlet_id}`;

  if (outlet.length === 0) {
    return { error: "Outlet not found" };
  }

  const products = await sql`
    SELECT p.epc, p.name 
    FROM products p
    LEFT JOIN rfid_events r ON p.epc = r.epc
    WHERE p.batch = ${batch}
    AND (r.outlet_id IS NULL OR r.outlet_id != ${outlet_id})
    ORDER BY p.epc
    LIMIT ${quantity}
  `;

  if (products.length < quantity) {
    return {
      error: `Only ${products.length} products available in batch ${batch} for dispatch`,
    };
  }

  const dispatchRecord = await sql`
    INSERT INTO dispatch_records (batch, outlet_id, quantity)
    VALUES (${batch}, ${outlet_id}, ${quantity})
    RETURNING *
  `;

  const epcs = products.map((p) => p.epc);

  await sql`
    INSERT INTO rfid_events (epc, location, outlet_id)
    SELECT epc, ${outlet.name}, ${outlet_id}
    FROM unnest(${epcs}::text[]) AS epc
  `;

  return {
    dispatch: dispatchRecord[0],
    outlet: outlet[0],
    products_dispatched: products.length,
    dispatched_products: products,
  };
}
export async function POST(request) {
  return handler(await request.json());
}