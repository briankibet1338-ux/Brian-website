async function handler() {
  const inventory = await sql`
    SELECT DISTINCT ON (p.epc) 
      p.epc,
      p.name,
      p.batch,
      p.expiry,
      r.location,
      r.timestamp as last_seen,
      wz.zone_name,
      wz.zone_type,
      wz.coordinates,
      o.name as outlet_name,
      o.location as outlet_location
    FROM products p
    LEFT JOIN rfid_events r ON p.epc = r.epc
    LEFT JOIN warehouse_zones wz ON r.zone_id = wz.id
    LEFT JOIN outlets o ON r.outlet_id = o.id
    ORDER BY p.epc, r.timestamp DESC NULLS LAST
  `;

  const batchSummary = await sql`
    SELECT 
      p.batch,
      COUNT(*) as total_products,
      COUNT(CASE WHEN o.name IS NOT NULL THEN 1 END) as dispatched_count,
      COUNT(CASE WHEN wz.zone_type = 'storage' THEN 1 END) as in_storage,
      COUNT(CASE WHEN wz.zone_type = 'dispatch' THEN 1 END) as in_dispatch,
      STRING_AGG(DISTINCT o.name, ', ') as dispatched_to_outlets
    FROM products p
    LEFT JOIN rfid_events r ON p.epc = r.epc
    LEFT JOIN warehouse_zones wz ON r.zone_id = wz.id
    LEFT JOIN outlets o ON r.outlet_id = o.id
    GROUP BY p.batch
    ORDER BY p.batch
  `;

  return {
    inventory: inventory,
    batch_summary: batchSummary,
    totalProducts: inventory.length,
    trackedProducts: inventory.filter((item) => item.location !== null).length,
    untrackedProducts: inventory.filter((item) => item.location === null)
      .length,
    dispatchedProducts: inventory.filter((item) => item.outlet_name !== null)
      .length,
    warehouseProducts: inventory.filter(
      (item) => item.zone_name !== null && item.outlet_name === null
    ).length,
  };
}
export async function POST(request) {
  return handler(await request.json());
}